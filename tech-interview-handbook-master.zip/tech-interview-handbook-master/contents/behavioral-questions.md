# Behavioral questions

[Contents have been moved to the website. Click here.](https://www.techinterviewhandbook.org/behavioral-interview-questions/).

<!-- TODO: Remove in future -->

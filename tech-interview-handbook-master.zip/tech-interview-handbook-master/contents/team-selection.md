---
id: team-selection
title: Team Selection
---

:::caution

This section is still WIP. Feel free to contribute ideas at [our GitHub issue](https://github.com/yangshun/tech-interview-handbook/issues/223).

:::

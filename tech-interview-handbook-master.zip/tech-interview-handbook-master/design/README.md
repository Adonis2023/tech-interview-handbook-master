# System Design

[Contents have been moved to the website. Click here.](https://www.techinterviewhandbook.org/system-design/).

<!-- TODO: Remove in future -->

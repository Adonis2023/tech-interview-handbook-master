# Networking

- Given an IPv4 IP address p and an integer n, return a list of CIDR strings that most succinctly represents the range of IP addresses from p to (p + n).
- Describe what happens when you enter a url in the web browser.
- Define UDP/TCP and give an example of both.

# Preparing

[Contents have been moved to the website. Click here.](https://www.techinterviewhandbook.org/coding-interview-prep/).

<!-- TODO: Remove in future -->
